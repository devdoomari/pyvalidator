from wrongtype import WrongType
from funcfail import FuncFail
from notequal import NotEqual
from surpluskey import SurplusKey
from missingkey import MissingKey
